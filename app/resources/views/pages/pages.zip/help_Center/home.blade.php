@extends('layouts.sitelayouts.header')

@section('content')
<style>
     body{
        background-color: #ffffff;
    }
    .card{
        width: 85%;
        float: none;
        margin-bottom: 10px;
        margin: 0 auto;
        border:none;
    }
</style>

<div class="container my-5">
    <div class="card my-5 " >
        <div class='text-center'>
            <p class="card-text "><h4>مركز المساعدة</h4></p>
        </div>
        @foreach ($help_Center as $item)
        <div class="row g-0">
            <div class="col-md-12">
                <div class="card-body">

                    <a class="btn text-secondary " type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                        {{ $item->question }}
                        <i class="bi bi-chevron-down"></i>
                    </a>
                    <div class="collapse" id="collapseExample">
                        <div class="card card-body">
                            <p class="card-text"><h4>{!! $item->answer !!}</h4></p>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
        </div>
        @endforeach
    </div>
</div>



@endsection
